# Sunday Football — V1

Application web mobile pour gérer votre tournoi de football.

## Fichiers

- `index.html` : structure de l'application
- `style.css` : interface mobile
- `app.js` : logique du tournoi et sauvegarde locale
- `manifest.webmanifest` : permet de préparer l'installation comme PWA
- `README.md` : instructions

## Règles V2 — pause avant chaque match

- La création du tournoi ne démarre jamais le chrono.
- Après la création du tournoi, le premier match est préparé et reste en pause.
- Le chrono démarre uniquement après le bouton `Commencer le match`.
- Après chaque match, le prochain match est préparé mais reste en pause.
- Il faut appuyer sur `Commencer le match` pour lancer son chrono.
- Si le navigateur est fermé pendant la pause, le match préparé est conservé.
- Si le navigateur est fermé pendant un match, le match actif et son chrono sont restaurés.

## Règles V1

- Victoire = 3 points.
- Égalité = 1 point pour chaque équipe.
- Défaite = 0 point.
- Une équipe qui gagne reste sur le terrain.
- L'équipe perdante va à la fin de la file.
- La prochaine équipe de la file entre.
- Si le match termine 0-0 à la fin du temps : les deux équipes sortent et les deux prochaines équipes entrent.
- Une équipe atteint 2 buts : victoire immédiate.
- Le classement est basé sur les points, puis le nombre de victoires, puis les défaites uniquement comme départage technique provisoire.
- Les buts ne servent pas au classement final.
- La phase finale affiche les 4 premières équipes.
- En cas d'égalité de points pour une place qualificative, la prochaine étape du projet doit déclencher un match éliminatoire de 5 minutes.

## Sauvegarde

L'état du tournoi est sauvegardé automatiquement dans `localStorage` après les actions et pendant le chrono.

Le bouton `Exporter` crée un fichier JSON de secours.

Le bouton `Importer` permet de restaurer une sauvegarde.

## Test sur ordinateur

Ouvrir `index.html` dans un navigateur moderne.

Pour un vrai fonctionnement PWA/offline et l'installation sur téléphone, il faudra ensuite servir les fichiers en HTTPS (par exemple GitHub Pages).

## Important

Cette V1 est volontairement simple. Avant d'ajouter des fonctions supplémentaires, testez la rotation avec votre groupe pendant un vrai dimanche et vérifiez que la file correspond exactement à vos règles.


## V3 — Phase finale

- Bouton `Passer aux demi-finales`.
- Si les 4e et 5e ont le même nombre de points, match éliminatoire 5 min / 2 buts pour décider de la 4e place.
- Demi-finale 1 : 1er vs 4e — 7 min / 2 buts.
- Demi-finale 2 : 2e vs 3e — 7 min / 2 buts.
- Finale : vainqueurs des demi-finales — 10 min / 3 buts.
- Chaque match de phase finale possède une pause avant le démarrage.
- Les équipes peuvent avoir une image/logo (maximum 2 Mo).
- Le dashboard final affiche le champion avec son image.
- Les buts ne sont pas utilisés pour classer la phase de classement.

## V4 — sauvegarde automatique + buteurs
- Chaque action importante est sauvegardée automatiquement dans `localStorage` sur le téléphone.
- Les buts et les buteurs sont sauvegardés immédiatement.
- La sauvegarde est également déclenchée quand l'application passe en arrière-plan ou est fermée.
- Les boutons **Exporter** et **Importer** restent disponibles comme copie de secours.
- Sous le bouton **⚽ But**, chaque joueur possède un petit bouton. Toucher le prénom enregistre directement le but et le buteur.
- Une liste compacte des buteurs est affichée pendant le match et conservée dans l'historique.


## V5 – nouvelles fonctionnalités
- 3 à 8 équipes, avec boutons Ajouter/Supprimer une équipe.
- Durée des matchs de classement configurable (5, 7 ou 10 min), 5 min par défaut.
- Premier match tiré aléatoirement à chaque nouveau tournoi.
- Classement des buteurs mis à jour à partir des buts enregistrés.
- Sauvegarde automatique conservée ; Importer/Exporter restent disponibles.
- Les demi-finales restent disponibles à partir de 4 équipes ; le mode 3 équipes reste utilisable pour les matchs de classement.
