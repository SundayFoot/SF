(() => {
  "use strict";

  const STORAGE_KEY = "sundayFootballTournamentV1";
  const $ = (id) => document.getElementById(id);

  const els = {
    setupScreen: $("setupScreen"),
    gameScreen: $("gameScreen"),
    teamCount: $("teamCount"),
    addTeamBtn: $("addTeamBtn"),
    removeTeamBtn: $("removeTeamBtn"),
    matchMinutes: $("matchMinutes"),
    teamForm: $("teamForm"),
    startTournamentBtn: $("startTournamentBtn"),
    newTournamentBtn: $("newTournamentBtn"),
    saveStatus: $("saveStatus"),
    resumeBanner: $("resumeBanner"),
    resumeText: $("resumeText"),
    continueBtn: $("continueBtn"),
    preMatchCard: $("preMatchCard"),
    activeMatchCard: $("activeMatchCard"),
    preTeamA: $("preTeamA"),
    preTeamB: $("preTeamB"),
    preMatchInfo: $("preMatchInfo"),
    startMatchBtn: $("startMatchBtn"),
    matchNumber: $("matchNumber"),
    timer: $("timer"),
    leaderPoints: $("leaderPoints"),
    teamAName: $("teamAName"),
    teamBName: $("teamBName"),
    scoreA: $("scoreA"),
    scoreB: $("scoreB"),
    goalABtn: $("goalABtn"),
    goalBBtn: $("goalBBtn"),
    winABtn: $("winABtn"),
    winBBtn: $("winBBtn"),
    drawBtn: $("drawBtn"),
    queueList: $("queueList"),
    rankingList: $("rankingList"),
    historyList: $("historyList"),
    exportBtn: $("exportBtn"),
    importInput: $("importInput"),
    finalScreen: $("finalScreen"),
    finalContent: $("finalContent"),
    dashboardScreen: $("dashboardScreen"),
    dashboardContent: $("dashboardContent"),
    toast: $("toast")
  };

  let state = null;
  let timerId = null;

  const defaultNames = ["Rouge", "Vert", "Jaune", "Bleu", "Sans maillot", "Noir", "Blanc", "Orange"];

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function showToast(message) {
    els.toast.textContent = message;
    els.toast.classList.add("show");
    clearTimeout(showToast.timeout);
    showToast.timeout = setTimeout(() => els.toast.classList.remove("show"), 2200);
  }

  function formatTime(seconds) {
    const safe = Math.max(0, Math.floor(Number(seconds) || 0));
    return String(Math.floor(safe / 60)).padStart(2, "0") + ":" + String(safe % 60).padStart(2, "0");
  }

  function getSetupDraft() {
    const draft = [];
    if (!els.teamForm) return draft;
    els.teamForm.querySelectorAll(".team-entry").forEach((entry, index) => {
      const get = (field) => entry.querySelector(`[data-field="${field}"]`)?.value || "";
      draft[index] = { name: get("name"), captain: get("captain"), players: get("players") };
    });
    return draft;
  }

  function renderTeamForm(draft = null) {
    const count = Math.max(3, Math.min(8, Number(els.teamCount.value) || 5));
    els.teamCount.value = String(count);
    const previous = draft || getSetupDraft();
    els.teamForm.innerHTML = "";
    for (let i = 0; i < count; i++) {
      const saved = previous[i] || {};
      const entry = document.createElement("div");
      entry.className = "team-entry";
      entry.innerHTML = `
        <div class="team-entry-head">
          <h3>Équipe ${i + 1}</h3>
          ${count > 3 ? `<button type="button" class="remove-team-inline" data-remove-team="${i}" aria-label="Supprimer cette équipe">✕</button>` : ""}
        </div>
        <div class="grid">
          <label>Nom
            <input data-field="name" data-index="${i}" value="${escapeHtml(saved.name || defaultNames[i] || "Équipe " + (i + 1))}" maxlength="40">
          </label>
          <label>Capitaine
            <input data-field="captain" data-index="${i}" value="${escapeHtml(saved.captain || "")}" placeholder="Nom du capitaine" maxlength="60">
          </label>
          <label>Joueurs
            <input data-field="players" data-index="${i}" value="${escapeHtml(saved.players || "")}" placeholder="Ex. Ali, Yassine, Karim" maxlength="300">
          </label>
          <label>Image / logo
            <input data-field="image" data-index="${i}" type="file" accept="image/*">
          </label>
        </div>
      `;
      els.teamForm.appendChild(entry);
    }

    els.teamForm.querySelectorAll("[data-remove-team]").forEach(btn => {
      btn.addEventListener("click", () => {
        const index = Number(btn.dataset.removeTeam);
        const current = getSetupDraft();
        current.splice(index, 1);
        els.teamCount.value = String(Math.max(3, Number(els.teamCount.value) - 1));
        renderTeamForm(current);
      });
    });
  }

  function addSetupTeam() {
    if (Number(els.teamCount.value) >= 8) {
      showToast("Maximum 8 équipes.");
      return;
    }
    const draft = getSetupDraft();
    els.teamCount.value = String(Number(els.teamCount.value) + 1);
    renderTeamForm(draft);
  }

  function removeSetupTeam() {
    if (Number(els.teamCount.value) <= 3) {
      showToast("Minimum 3 équipes.");
      return;
    }
    const draft = getSetupDraft();
    draft.pop();
    els.teamCount.value = String(Number(els.teamCount.value) - 1);
    renderTeamForm(draft);
  }

  function createEmptyState(teams, minutes) {
    return {
      version: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      settings: { matchMinutes: minutes },
      teams,
      queue: [],
      active: null,
      matchNumber: 0,
      scoreA: 0,
      scoreB: 0,
      scorersA: [],
      scorersB: [],
      secondsLeft: minutes * 60,
      history: [],
      finals: null,
      matchStarted: false,
      phase: "league",
      phaseMatch: null,
      phaseMatchStarted: false,
      phaseSecondsLeft: 0,
      phaseTimerId: null,
      semifinalResults: [],
      finalResult: null,
      tournamentWinnerId: null
    };
  }

  function saveState() {
    if (!state) return;
    state.updatedAt = new Date().toISOString();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      els.saveStatus.textContent = "✓ Sauvegardé automatiquement";
    } catch (error) {
      els.saveStatus.textContent = "⚠️ Sauvegarde locale indisponible";
      showToast("Impossible de sauvegarder localement.");
    }
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.teams)) return null;
      if (!Array.isArray(parsed.scorersA)) parsed.scorersA = [];
      if (!Array.isArray(parsed.scorersB)) parsed.scorersB = [];
      if (parsed.phaseMatch) {
        if (!Array.isArray(parsed.phaseMatch.scorersA)) parsed.phaseMatch.scorersA=[];
        if (!Array.isArray(parsed.phaseMatch.scorersB)) parsed.phaseMatch.scorersB=[];
      }
      return parsed;
    } catch {
      return null;
    }
  }

  function clearState() {
    try { localStorage.removeItem(STORAGE_KEY); } catch {}
  }

  function stopTimer() {
    if (timerId !== null) {
      clearInterval(timerId);
      timerId = null;
    }
  }

  function startTimer() {
    stopTimer();
    if (!state || !state.active || !state.matchStarted) return;
    timerId = setInterval(() => {
      if (!state || !state.active) return;
      state.secondsLeft = Math.max(0, state.secondsLeft - 1);
      renderGame();
      saveState();

      if (state.secondsLeft === 0) {
        stopTimer();
        if (state.scoreA === 0 && state.scoreB === 0) {
          finishDraw();
        } else {
          // According to the requested rule, the normal draw case is 0-0.
          // If goals were scored but nobody reached 2, the organizer decides.
          showToast("Temps écoulé : choisis le gagnant.");
        }
      }
    }, 1000);
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  function startFirstMatch() {
    shuffleArray(state.queue);
    const firstA = state.queue.shift();
    const firstB = state.queue.shift();
    if (firstA === undefined || firstB === undefined) {
      showToast("Pas assez d'équipes.");
      return;
    }
    state.active = { a: firstA, b: firstB };
    state.matchNumber = 1;
    state.scoreA = 0;
    state.scoreB = 0;
    state.scorersA = [];
    state.scorersB = [];
    state.secondsLeft = state.settings.matchMinutes * 60;
    state.matchStarted = false;
    saveState();
    showGame();
    renderGame();
    // Intentionally paused: organizer must tap "Commencer le match".
  }

  function startNextMatchFromWinner(winnerId, loserId) {
    state.queue.push(loserId);
    const nextId = state.queue.shift();

    if (nextId === undefined) {
      state.active = null;
      state.matchStarted = false;
      stopTimer();
      saveState();
      renderGame();
      showToast("Plus d'équipe disponible.");
      return;
    }

    state.active = { a: winnerId, b: nextId };
    state.matchNumber += 1;
    state.scoreA = 0;
    state.scoreB = 0;
    state.scorersA = [];
    state.scorersB = [];
    state.secondsLeft = state.settings.matchMinutes * 60;
    state.matchStarted = false;
    saveState();
    renderGame();
    // Pause between matches. Timer starts only after explicit tap.
  }

  function finishWinner(side) {
    if (!state?.active || !state.matchStarted) return;

    stopTimer();

    const winnerId = side === "A" ? state.active.a : state.active.b;
    const loserId = side === "A" ? state.active.b : state.active.a;
    const winner = state.teams[winnerId];
    const loser = state.teams[loserId];

    winner.wins += 1;
    winner.points += 3;
    loser.losses += 1;

    winner.goalsFor += state.scoreA;
    winner.goalsAgainst += state.scoreB;
    loser.goalsFor += state.scoreB;
    loser.goalsAgainst += state.scoreA;

    state.history.push({
      number: state.matchNumber,
      teamAId: state.active.a,
      teamBId: state.active.b,
      type: "win",
      text: `${winner.name} gagne ${state.scoreA}-${state.scoreB} contre ${loser.name}. ${winner.name} reste sur le terrain.`,
      scorersA: [...(state.scorersA || [])],
      scorersB: [...(state.scorersB || [])]
    });

    saveState();
    startNextMatchFromWinner(winnerId, loserId);
  }

  function finishDraw() {
    if (!state?.active || !state.matchStarted) return;

    stopTimer();

    const aId = state.active.a;
    const bId = state.active.b;
    const a = state.teams[aId];
    const b = state.teams[bId];

    a.draws += 1;
    b.draws += 1;
    a.points += 1;
    b.points += 1;

    a.goalsFor += state.scoreA;
    a.goalsAgainst += state.scoreB;
    b.goalsFor += state.scoreB;
    b.goalsAgainst += state.scoreA;

    state.history.push({
      number: state.matchNumber,
      teamAId: state.active.a,
      teamBId: state.active.b,
      type: "draw",
      text: `Égalité ${a.name} ${state.scoreA}-${state.scoreB} ${b.name}. Les deux sortent.`,
      scorersA: [...(state.scorersA || [])],
      scorersB: [...(state.scorersB || [])]
    });

    // Both teams go to the end of the queue.
    state.queue.push(aId, bId);

    const nextA = state.queue.shift();
    const nextB = state.queue.shift();

    if (nextA === undefined || nextB === undefined) {
      state.active = null;
      saveState();
      renderGame();
      showToast("Égalité enregistrée. Il faut deux équipes disponibles.");
      return;
    }

    state.active = { a: nextA, b: nextB };
    state.matchNumber += 1;
    state.scoreA = 0;
    state.scoreB = 0;
    state.scorersA = [];
    state.scorersB = [];
    state.secondsLeft = state.settings.matchMinutes * 60;
    state.matchStarted = false;

    saveState();
    renderGame();
    // Pause between matches. Timer starts only after explicit tap.
  }

  function startCurrentMatch() {
    if (!state?.active || state.matchStarted) return;
    state.matchStarted = true;
    state.secondsLeft = state.settings.matchMinutes * 60;
    saveState();
    renderGame();
    startTimer();
    showToast("Match commencé !");
  }

  function ensureScorerState() {
    if (!state) return;
    if (!Array.isArray(state.scorersA)) state.scorersA = [];
    if (!Array.isArray(state.scorersB)) state.scorersB = [];
  }

  function addGoal(side, scorerName = "") {
    if (!state?.active || !state.matchStarted) return;

    ensureScorerState();

    if (side === "A") {
      state.scoreA += 1;
      state.scorersA.push(scorerName || "Buteur non renseigné");
    } else if (side === "B") {
      state.scoreB += 1;
      state.scorersB.push(scorerName || "Buteur non renseigné");
    } else {
      return;
    }

    // Sauvegarde immédiate après chaque but / buteur.
    saveState();
    renderGame();

    // Le premier à 2 buts gagne automatiquement.
    if (state.scoreA >= 2) {
      finishWinner("A");
      return;
    }

    if (state.scoreB >= 2) {
      finishWinner("B");
      return;
    }
  }

  function scorerSummary(names) {
    if (!Array.isArray(names) || !names.length) return "Aucun buteur";
    const counts = new Map();
    names.forEach(name => counts.set(name, (counts.get(name) || 0) + 1));
    return [...counts.entries()].map(([name, count]) =>
      `${escapeHtml(name)}${count > 1 ? ` ×${count}` : ""}`
    ).join(" · ");
  }

  function playerButtonsHtml(team, side, phase = false) {
    const players = Array.isArray(team?.players) ? team.players : [];
    if (!players.length) {
      return `<div class="players-empty">Aucun joueur renseigné</div>`;
    }

    return `<div class="scorer-area">
      <div class="scorer-label">Buteur :</div>
      <div class="player-buttons">
        ${players.map((player, index) => `
          <button type="button" class="player-btn" data-${phase ? "pplayer" : "player"}side="${side}" data-${phase ? "pplayer" : "player"}name="${escapeHtml(player)}">${escapeHtml(player)}</button>
        `).join("")}
      </div>
    </div>`;
  }

  function sortedTeams() {
    return [...state.teams].sort((a, b) =>
      b.points - a.points ||
      b.wins - a.wins ||
      a.losses - b.losses ||
      a.name.localeCompare(b.name)
    );
  }

  function getScorerRanking() {
    const counts = new Map();
    const add = (name) => {
      const clean = String(name || "").trim();
      if (!clean || clean === "Buteur non renseigné") return;
      counts.set(clean, (counts.get(clean) || 0) + 1);
    };

    (state.history || []).forEach(h => {
      (h.scorersA || []).forEach(add);
      (h.scorersB || []).forEach(add);
    });
    (state.scorersA || []).forEach(add);
    (state.scorersB || []).forEach(add);
    (state.phaseMatch?.scorersA || []).forEach(add);
    (state.phaseMatch?.scorersB || []).forEach(add);
    (state.semifinalResults || []).forEach(r => {
      (r.scorersA || []).forEach(add);
      (r.scorersB || []).forEach(add);
    });
    if (state.finals?.playoff) {
      (state.finals.playoff.scorersA || []).forEach(add);
      (state.finals.playoff.scorersB || []).forEach(add);
    }
    if (state.finalResult) {
      (state.finalResult.scorersA || []).forEach(add);
      (state.finalResult.scorersB || []).forEach(add);
    }

    return [...counts.entries()].sort((a,b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  }

  function renderGame() {
    if (!state) return;

    els.matchNumber.textContent = state.active ? "#" + state.matchNumber : "—";
    els.timer.textContent = formatTime(state.secondsLeft);

    if (state.active) {
      const preA = state.teams[state.active.a];
      const preB = state.teams[state.active.b];
      els.preTeamA.textContent = preA?.name || "—";
      els.preTeamB.textContent = preB?.name || "—";
      els.preMatchCard.classList.toggle("hidden", !!state.matchStarted);
      els.activeMatchCard.classList.toggle("hidden", !state.matchStarted);
      els.startMatchBtn.disabled = !!state.matchStarted;
      els.startMatchBtn.textContent = state.matchStarted ? "Match en cours" : "▶️ Commencer le match";
      els.preMatchInfo.textContent = state.matchStarted
        ? "Le chrono est lancé."
        : `Durée : ${state.settings.matchMinutes} minutes. Le chrono démarrera après le bouton.`;
    } else {
      els.preMatchCard.classList.add("hidden");
      els.activeMatchCard.classList.add("hidden");
    }

    if (state.active) {
      const a = state.teams[state.active.a];
      const b = state.teams[state.active.b];

      els.teamAName.textContent = a.name;
      els.teamBName.textContent = b.name;
      els.scoreA.textContent = state.scoreA;
      els.scoreB.textContent = state.scoreB;
      ensureScorerState();
      const playersA = document.getElementById("playersA");
      const playersB = document.getElementById("playersB");
      if (playersA) playersA.innerHTML = playerButtonsHtml(a,"A",false);
      if (playersB) playersB.innerHTML = playerButtonsHtml(b,"B",false);
      const scorersAEl = document.getElementById("scorersA");
      const scorersBEl = document.getElementById("scorersB");
      if (scorersAEl) scorersAEl.innerHTML = `⚽ ${scorerSummary(state.scorersA)}`;
      if (scorersBEl) scorersBEl.innerHTML = `⚽ ${scorerSummary(state.scorersB)}`;
      els.leaderPoints.textContent = sortedTeams()[0]?.points ?? 0;
      els.drawBtn.textContent = `🤝 Égalité — 0-0 après ${state.settings.matchMinutes} min`;
    } else {
      els.teamAName.textContent = "—";
      els.teamBName.textContent = "—";
      els.scoreA.textContent = "0";
      els.scoreB.textContent = "0";
      els.leaderPoints.textContent = sortedTeams()[0]?.points ?? 0;
      els.drawBtn.textContent = `🤝 Égalité — 0-0 après ${state.settings.matchMinutes} min`;
    }

    els.queueList.innerHTML = state.queue.length
      ? state.queue.map((id, index) => {
          const t = state.teams[id];
          return `<div class="queue-item">
            <div class="row-left"><span class="queue-num">${index + 1}</span><strong>${escapeHtml(t.name)}</strong></div>
            <span class="badges">${t.points} pts</span>
          </div>`;
        }).join("")
      : `<div class="muted">Aucune équipe en attente.</div>`;

    els.rankingList.innerHTML = sortedTeams().map((t, i) =>
      `<div class="rank-item">
        <div class="row-left"><strong>${i + 1}. ${escapeHtml(t.name)}</strong></div>
        <span class="badges">${t.points} pts · ${t.wins}V · ${t.draws}N · ${t.losses}D</span>
      </div>`
    ).join("");

    const scorerRankingList = document.getElementById("scorerRankingList");
    if (scorerRankingList) {
      const scorers = getScorerRanking();
      scorerRankingList.innerHTML = scorers.length
        ? scorers.map(([name, goals], i) => `<div class="rank-item"><strong>${i + 1}. ${escapeHtml(name)}</strong><span class="badges">${goals} but${goals > 1 ? "s" : ""}</span></div>`).join("")
        : `<div class="muted">Aucun but enregistré.</div>`;
    }

    els.historyList.innerHTML = state.history.length
      ? state.history.slice().reverse().map(h => {
          const aScorers = Array.isArray(h.scorersA) && h.scorersA.length ? scorerSummary(h.scorersA) : "";
          const bScorers = Array.isArray(h.scorersB) && h.scorersB.length ? scorerSummary(h.scorersB) : "";
          const scorerLine = (aScorers || bScorers)
            ? `<div class="history-scorers">⚽ ${aScorers || "—"} ${bScorers ? ` | ${bScorers}` : ""}</div>`
            : "";
          return `<div class="history-item"><strong>#${h.number}</strong><div><span>${escapeHtml(h.text)}</span>${scorerLine}</div></div>`;
        }).join("")
      : `<div class="muted">Aucun match terminé.</div>`;

    renderFinals();
  }

  function showGame() {
    els.setupScreen.classList.add("hidden");
    els.gameScreen.classList.remove("hidden");
    els.resumeBanner.classList.add("hidden");
  }

  function showSetup() {
    stopTimer();
    els.gameScreen.classList.add("hidden");
    els.setupScreen.classList.remove("hidden");
  }


  function teamImageHtml(team, cls="team-logo") {
    return team?.image
      ? `<img class="${cls}" src="${escapeHtml(team.image)}" alt="Image de ${escapeHtml(team.name)}">`
      : `<div class="${cls} placeholder">⚽</div>`;
  }

  function phaseDurationSeconds() {
    if (state.phase==="playoff") return 300;
    if (state.phase==="semifinal") return 420;
    if (state.phase==="final") return 600;
    return 0;
  }

  function phaseGoalLimit() {
    return state.phase==="final" ? 3 : 2;
  }

  function phaseLabel() {
    if (state.phase==="playoff") return "MATCH ÉLIMINATOIRE";
    if (state.phase==="semifinal") return "DEMI-FINALE";
    return "FINALE";
  }

  function stopPhaseTimer() {
    if (state?.phaseTimerId) clearInterval(state.phaseTimerId);
    if (state) state.phaseTimerId=null;
  }

  function preparePhaseMatch(phase,a,b,label) {
    stopPhaseTimer();
    state.phase=phase;
    state.phaseMatch={a,b,label,scoreA:0,scoreB:0,scorersA:[],scorersB:[]};
    state.phaseMatchStarted=false;
    state.phaseSecondsLeft=phaseDurationSeconds();
    saveState();
    renderFinals();
  }

  function startPhaseMatch() {
    if (!state?.phaseMatch || state.phaseMatchStarted) return;
    state.phaseMatchStarted=true;
    state.phaseSecondsLeft=phaseDurationSeconds();
    saveState();
    renderFinals();
    state.phaseTimerId=setInterval(()=>{
      if (!state?.phaseMatchStarted) return;
      state.phaseSecondsLeft=Math.max(0,state.phaseSecondsLeft-1);
      renderFinals(); saveState();
      if (state.phaseSecondsLeft===0) {
        stopPhaseTimer();
        showToast("Temps écoulé : choisis le vainqueur.");
      }
    },1000);
  }

  function resumePhaseTimer() {
    if (!state?.phaseMatch || !state.phaseMatchStarted) return;
    stopPhaseTimer();
    state.phaseTimerId=setInterval(()=>{
      if (!state?.phaseMatchStarted) return;
      state.phaseSecondsLeft=Math.max(0,state.phaseSecondsLeft-1);
      renderFinals(); saveState();
      if (state.phaseSecondsLeft===0) {
        stopPhaseTimer();
        showToast("Temps écoulé : choisis le vainqueur.");
      }
    },1000);
  }

  function addPhaseGoal(side, scorerName = "") {
    if (!state?.phaseMatch || !state.phaseMatchStarted) return;
    if (!Array.isArray(state.phaseMatch.scorersA)) state.phaseMatch.scorersA=[];
    if (!Array.isArray(state.phaseMatch.scorersB)) state.phaseMatch.scorersB=[];

    if (side==="A") {
      state.phaseMatch.scoreA++;
      state.phaseMatch.scorersA.push(scorerName || "Buteur non renseigné");
    } else if (side==="B") {
      state.phaseMatch.scoreB++;
      state.phaseMatch.scorersB.push(scorerName || "Buteur non renseigné");
    } else {
      return;
    }

    saveState();
    renderFinals();
    const limit=phaseGoalLimit();
    if (state.phaseMatch.scoreA>=limit) finishPhaseMatch("A");
    else if (state.phaseMatch.scoreB>=limit) finishPhaseMatch("B");
  }

  function finishPhaseMatch(side) {
    if (!state?.phaseMatch || !state.phaseMatchStarted) return;
    const m=state.phaseMatch;
    const winnerId=side==="A"?m.a:m.b;
    const loserId=side==="A"?m.b:m.a;
    stopPhaseTimer();

    if (state.phase==="playoff") {
      const r=sortedTeams();
      state.finals={top4:[r[0].id,r[1].id,r[2].id,winnerId],playoff:{winnerId,loserId,scoreA:m.scoreA,scoreB:m.scoreB,scorersA:[...(m.scorersA||[])],scorersB:[...(m.scorersB||[])]}};
      state.semifinalResults=[];
      preparePhaseMatch("semifinal",r[0].id,winnerId,"Demi-finale 1");
      return;
    }

    if (state.phase==="semifinal") {
      state.semifinalResults=state.semifinalResults||[];
      state.semifinalResults.push({winnerId,loserId,scoreA:m.scoreA,scoreB:m.scoreB,label:m.label,scorersA:[...(m.scorersA||[])],scorersB:[...(m.scorersB||[])]});
      if (state.semifinalResults.length===1) {
        const top4=state.finals.top4;
        preparePhaseMatch("semifinal",top4[1],top4[2],"Demi-finale 2");
      } else {
        const f1=state.semifinalResults[0].winnerId;
        const f2=state.semifinalResults[1].winnerId;
        preparePhaseMatch("final",f1,f2,"Finale");
      }
      return;
    }

    if (state.phase==="final") {
      state.finalResult={winnerId,loserId,scoreA:m.scoreA,scoreB:m.scoreB,scorersA:[...(m.scorersA||[])],scorersB:[...(m.scorersB||[])]};
      state.tournamentWinnerId=winnerId;
      state.phase="complete";
      state.phaseMatch=null;
      state.phaseMatchStarted=false;
      state.phaseSecondsLeft=0;
      saveState(); renderFinals();
      showToast(`🏆 ${state.teams[winnerId].name} est champion !`);
    }
  }

  function launchSemifinals() {
    const r=sortedTeams();
    if (r.length<4) { showToast("Il faut au moins 4 équipes pour les demi-finales."); return; }
    if (r.length>=5 && r[3].points===r[4].points) {
      state.finals={top4:[r[0].id,r[1].id,r[2].id,null],playoff:{fourthId:r[3].id,fifthId:r[4].id}};
      preparePhaseMatch("playoff",r[3].id,r[4].id,"Match éliminatoire pour la 4e place");
      return;
    }
    state.finals={top4:r.slice(0,4).map(t=>t.id)};
    state.semifinalResults=[];
    preparePhaseMatch("semifinal",r[0].id,r[3].id,"Demi-finale 1");
  }

  function phaseMatchHtml() {
    if (!state.phaseMatch) return "";
    const a=state.teams[state.phaseMatch.a], b=state.teams[state.phaseMatch.b];
    const dur=state.phase==="playoff"?"5 min":state.phase==="semifinal"?"7 min":"10 min";
    const goals=state.phase==="final"?3:2;
    const scorersA = state.phaseMatch.scorersA || [];
    const scorersB = state.phaseMatch.scorersB || [];
    return `<div class="phase-card">
      <div class="phase-title">${phaseLabel()}</div>
      <div class="phase-sub">${escapeHtml(state.phaseMatch.label)} · ${dur} · ${goals} buts</div>
      <div class="teams">
        <div class="team-side">
          ${teamImageHtml(a)}
          <div class="team-name">${escapeHtml(a.name)}</div>
          <div class="score">${state.phaseMatch.scoreA}</div>
          ${state.phaseMatchStarted ? `<button class="goal" data-pgoal="A">⚽ But</button>${playerButtonsHtml(a,"A",true)}<div class="scorer-list">⚽ ${scorerSummary(scorersA)}</div>` : ""}
        </div>
        <div class="versus">VS</div>
        <div class="team-side">
          ${teamImageHtml(b)}
          <div class="team-name">${escapeHtml(b.name)}</div>
          <div class="score">${state.phaseMatch.scoreB}</div>
          ${state.phaseMatchStarted ? `<button class="goal" data-pgoal="B">⚽ But</button>${playerButtonsHtml(b,"B",true)}<div class="scorer-list">⚽ ${scorerSummary(scorersB)}</div>` : ""}
        </div>
      </div>
      <div class="stat"><span>Temps</span><strong>${formatTime(state.phaseSecondsLeft)}</strong></div>
      ${!state.phaseMatchStarted
        ? `<button id="startPhaseMatchBtn" class="primary full">▶️ Commencer ${phaseLabel().toLowerCase()}</button>`
        : `<div class="action-grid"><button class="win" data-pwin="A">🏆 ${escapeHtml(a.name)} gagne</button><button class="win" data-pwin="B">🏆 ${escapeHtml(b.name)} gagne</button></div>`}
      <p class="hint">Le chrono démarre seulement après le bouton. Cliquer sur le nom d'un joueur enregistre directement son but.</p>
    </div>`;
  }

  function renderFinals() {
    if (!state || state.teams.length<4) return;
    els.finalScreen.classList.remove("hidden");
    let html=`<div class="phase-card"><div class="phase-title">📊 Classement</div>
      <div class="phase-sub">3 pts victoire · 1 pt égalité · 0 pt défaite</div>
      ${sortedTeams().map((t,i)=>`<div class="rank-item"><strong>${i+1}. ${escapeHtml(t.name)}</strong><span class="badges">${t.points} pts · ${t.wins}V · ${t.draws}N · ${t.losses}D</span></div>`).join("")}
    </div>`;

    if (state.phase==="league") {
      if (state.teams.length >= 4) {
        html+=`<div class="phase-card"><div class="phase-title">🏁 Phase finale</div>
          <p class="muted">Quand la phase de classement est terminée, appuie ici.</p>
          <button id="goSemifinalsBtn" class="primary full">🏆 Passer aux demi-finales</button></div>`;
      } else {
        html+=`<div class="phase-card"><div class="phase-title">ℹ️ Tournoi à 3 équipes</div>
          <p class="muted">Le mode 3 équipes fonctionne normalement pour les matchs de classement. Les demi-finales nécessitent au moins 4 équipes.</p></div>`;
      }
    } else if (state.phaseMatch) {
      html+=phaseMatchHtml();
    }

    if (state.semifinalResults?.length) {
      html+=`<div class="phase-card"><div class="phase-title">Demi-finales</div>
        ${state.semifinalResults.map(r=>`<div class="history-item"><strong>${escapeHtml(r.label)}</strong><span>🏆 ${escapeHtml(state.teams[r.winnerId].name)} · ${r.scoreA}-${r.scoreB}</span></div>`).join("")}
      </div>`;
    }

    if (state.finalResult) {
      const w=state.teams[state.finalResult.winnerId];
      html+=`<div class="phase-card final-dashboard"><div class="trophy">🏆</div><div class="phase-title">CHAMPION</div>${teamImageHtml(w,"winner-logo")}<div class="winner-name">${escapeHtml(w.name)}</div><p>Champion du tournoi</p></div>`;
    }

    els.finalContent.innerHTML=html;
    const go=document.getElementById("goSemifinalsBtn");
    if(go) go.addEventListener("click",launchSemifinals);
    const startBtn=document.getElementById("startPhaseMatchBtn");
    if(startBtn) startBtn.addEventListener("click",startPhaseMatch);
    els.finalContent.querySelectorAll("[data-pgoal]").forEach(b=>b.addEventListener("click",()=>addPhaseGoal(b.dataset.pgoal)));
    els.finalContent.querySelectorAll("[data-pplayerside]").forEach(b=>b.addEventListener("click",()=>addPhaseGoal(b.dataset.pplayerside,b.dataset.pplayername)));
    els.finalContent.querySelectorAll("[data-pwin]").forEach(b=>b.addEventListener("click",()=>finishPhaseMatch(b.dataset.pwin)));

    els.dashboardScreen.classList.remove("hidden");
    let d=`<div class="phase-card">`;
    if(state.tournamentWinnerId!==null){
      const w=state.teams[state.tournamentWinnerId];
      d+=`<div class="final-dashboard"><div class="trophy">🏆</div>${teamImageHtml(w,"winner-logo")}<div class="winner-name">${escapeHtml(w.name)}</div><p>Champion du tournoi</p></div>`;
    } else if(state.finals?.top4){
      d+=`<div class="phase-title">Top 4 / qualification</div>${state.finals.top4.map((id,i)=>id===null?`<div class="rank-item"><strong>${i+1}. À déterminer</strong></div>`:`<div class="rank-item"><strong>${i+1}. ${escapeHtml(state.teams[id].name)}</strong><span class="badges">${state.teams[id].points} pts</span></div>`).join("")}`;
    } else {
      d+=`<div class="phase-title">📱 Dashboard</div><p class="muted">Le dashboard final apparaîtra ici.</p>`;
    }
    d+=`</div>`;
    els.dashboardContent.innerHTML=d;
  }

  async function readImageAsDataUrl(file) {
    if (!file) return "";
    if (!file.type.startsWith("image/")) return "";
    if (file.size > 2000000) {
      showToast("Image trop grande (maximum 2 Mo).");
      return "";
    }
    return await new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => resolve("");
      reader.readAsDataURL(file);
    });
  }

  async function collectTeams() {
    const count = Number(els.teamCount.value);
    const teams = [];
    for (let i=0;i<count;i++) {
      const nameInput=els.teamForm.querySelector(`[data-field="name"][data-index="${i}"]`);
      const captainInput=els.teamForm.querySelector(`[data-field="captain"][data-index="${i}"]`);
      const playersInput=els.teamForm.querySelector(`[data-field="players"][data-index="${i}"]`);
      const imageInput=els.teamForm.querySelector(`[data-field="image"][data-index="${i}"]`);
      const name=(nameInput?.value||"").trim() || `Équipe ${i+1}`;
      const captain=(captainInput?.value||"").trim();
      const players=(playersInput?.value||"").split(",").map(v=>v.trim()).filter(Boolean);
      const image=await readImageAsDataUrl(imageInput?.files?.[0]);
      teams.push({id:i,name,captain,players,image,wins:0,draws:0,losses:0,points:0,goalsFor:0,goalsAgainst:0});
    }
    return teams;
  }

  async function beginTournament() {
    const teams = await collectTeams();
    const minutes = Math.max(1, Math.min(30, Number(els.matchMinutes.value) || 5));

    state = createEmptyState(teams, minutes);
    state.queue = teams.map((_, index) => index);

    startFirstMatch();
    showToast("Tournoi créé et sauvegardé.");
  }

  function resumeExisting() {
    const saved = loadState();
    if (!saved || !saved.active) return false;

    state = saved;
    showGame();
    renderGame();
    if (state.matchStarted) startTimer();
    return true;
  }

  function offerResume() {
    const saved = loadState();
    if (!saved) return;

    const active = saved.active;
    if (!active) return;

    const a = saved.teams[active.a]?.name || "Équipe A";
    const b = saved.teams[active.b]?.name || "Équipe B";

    els.resumeText.textContent = `Match #${saved.matchNumber} : ${a} ${saved.scoreA}-${saved.scoreB} ${b}.`;
    els.resumeBanner.classList.remove("hidden");
  }

  function exportTournament() {
    if (!state) {
      showToast("Aucun tournoi actif.");
      return;
    }

    const payload = JSON.stringify(state, null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const date = new Date().toISOString().slice(0, 10);
    link.href = url;
    link.download = `Sunday_Football_${date}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast("Copie de sauvegarde exportée.");
  }

  function validateImportedState(data) {
    return data &&
      data.version === 1 &&
      Array.isArray(data.teams) &&
      data.teams.length >= 4 &&
      Array.isArray(data.queue) &&
      typeof data.settings?.matchMinutes === "number";
  }

  async function importTournament(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const imported = JSON.parse(text);

      if (!validateImportedState(imported)) {
        throw new Error("Format invalide");
      }

      state = imported;
      saveState();
      showGame();
      renderGame();
      if (state.active) startTimer();
      showToast("Tournoi restauré.");
    } catch {
      showToast("Fichier de sauvegarde invalide.");
    } finally {
      event.target.value = "";
    }
  }

  function newTournament() {
    const ok = confirm("Commencer un nouveau tournoi ? Le tournoi actuel est déjà sauvegardé automatiquement sur ce téléphone. L'export reste disponible comme copie de secours.");
    if (!ok) return;

    clearState();
    state = null;
    stopTimer();
    els.resumeBanner.classList.add("hidden");
    showSetup();
    renderTeamForm();
    showToast("Nouveau tournoi.");
  }

  els.teamCount.addEventListener("change", () => renderTeamForm());
  els.addTeamBtn?.addEventListener("click", addSetupTeam);
  els.removeTeamBtn?.addEventListener("click", removeSetupTeam);
  els.startTournamentBtn.addEventListener("click", beginTournament);
  els.newTournamentBtn.addEventListener("click", newTournament);
  els.continueBtn.addEventListener("click", () => {
    const saved = loadState();
    if (!saved) return;
    state = saved;
    showGame();
    renderGame();
    if (state.matchStarted) startTimer();
  });

  els.startMatchBtn.addEventListener("click", startCurrentMatch);
  els.goalABtn.addEventListener("click", () => addGoal("A"));
  els.goalBBtn.addEventListener("click", () => addGoal("B"));
  els.activeMatchCard.addEventListener("click", (event) => {
    const button = event.target.closest("[data-playerside]");
    if (!button) return;
    addGoal(button.dataset.playerside, button.dataset.playername);
  });
  els.winABtn.addEventListener("click", () => finishWinner("A"));
  els.winBBtn.addEventListener("click", () => finishWinner("B"));
  els.drawBtn.addEventListener("click", finishDraw);
  els.exportBtn.addEventListener("click", exportTournament);
  els.importInput.addEventListener("change", importTournament);

  renderTeamForm();

  const existing = loadState();
  if (existing?.active) {
    els.gameScreen.classList.remove("hidden");
    els.setupScreen.classList.add("hidden");
    state = existing;
    renderGame();
    offerResume();
    if (state.matchStarted) startTimer();
  }
})();

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden" && state) saveState();
  });

  window.addEventListener("beforeunload", () => {
    if (state) saveState();
  });
